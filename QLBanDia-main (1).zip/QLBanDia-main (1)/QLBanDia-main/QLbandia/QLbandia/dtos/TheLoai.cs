﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLbandia.dtos
{
    public class TheLoai
    {

        private string matl;
        private string tentl;

      
        public TheLoai(DataRow row)
        {
            this.matl = row["MaTL"].ToString();
            this.tentl = row["TenTL"].ToString();
        }

        public TheLoai(string matl, string tentl)
        {
            this.Matl = matl;
            this.Tentl = tentl;
        }

        public string Matl
        {
            get { return matl; }
            set { matl = value; }
        }

        public string Tentl
        {
            get { return tentl; }
            set { tentl = value; }
        }
    }
}
