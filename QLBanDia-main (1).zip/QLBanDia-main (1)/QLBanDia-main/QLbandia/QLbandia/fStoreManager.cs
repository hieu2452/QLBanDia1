﻿using QLbandia.DAO;
using QLbandia.dtos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Media.Imaging;

namespace QLbandia
{
    public partial class fStoreManager : Form
    {
        public fStoreManager()
        {
            InitializeComponent();
            HienThi();

        }

        public void HienThi()
        {

            HienTheLoaiTheoID();
            HienNSXTheoID();
            cbNSX.SelectedIndex = -1;
            cbTheLoai.SelectedIndex = -1;
            LoadDia();
        }


        #region method

        public void LoadDia()
        {
            flStore.Controls.Clear();

            List<Dia> dialist = DiaDAO.Instance.LoadDiaList();

            foreach( Dia item in dialist)
            {
                Button btn = new Button() { Width = DiaDAO.DiaWidth, Height = DiaDAO.DiaHeight };
                btn.Text = item.Tendia;
                // btn.BackgroundImage = Image.FromFile(item.Anh);
                // btn.BackgroundImageLayout = ImageLayout.Stretch;
                btn.Tag = item;
                btn.Click += btn_Click;

                flStore.Controls.Add(btn);

            }

            
          
        }

        void ShowBill(string Madia)
        {
            lsvKhoDia.Items.Clear();
            Dia dia = DiaDAO.Instance.GetDiaByMaDia(Madia);
            ListViewItem lsvItem = new ListViewItem(dia.Madia);
            lsvItem.SubItems.Add(dia.Tendia);
            lsvItem.SubItems.Add(dia.Soluong.ToString());
            lsvItem.SubItems.Add(dia.Dongianhap.ToString());
            lsvItem.SubItems.Add(dia.Dongiaban.ToString());
            lsvKhoDia.Items.Add(lsvItem);
        }


        #endregion


        #region event

        private void btn_Click(object sender, EventArgs e)
        {
            
            string MaDia = ((sender as Button).Tag as Dia).Madia;
            lsvKhoDia.Tag = (sender as Button).Tag;

            ShowBill(MaDia);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(button1.BackgroundImage.ToString());
        }

        private void fStoreManager_Load(object sender, EventArgs e)
        {
           // button1.BackgroundImage = ((System.Drawing.Image)(Properties.Resources.gowdvd));
           
        }

        void HienTheLoaiTheoID()
        {
            List<TheLoai> listTheLoai = TheLoaiDAO.Instance.GetListCategory();
            cbTheLoai.DataSource = listTheLoai;
            cbTheLoai.DisplayMember = "TenTL";
            cbTheLoai.ValueMember = "MaTL";
        }

        void HienNSXTheoID()
        {
            List<NSX> listTheLoai = NsxDAO.Instance.GetListCategory();
            cbNSX.DataSource = listTheLoai;
            cbNSX.DisplayMember = "TenNSX";
            cbNSX.ValueMember = "MANSX";
        }

        public void HienthiThongTin()
        {

        }
        #endregion

        private void cbTheLoai_SelectedIndexChanged(object sender, EventArgs e)
        {
/*
            if (cbTheLoai.SelectedIndex > -1)
            {
                string maTL = "";

                ComboBox cb = sender as ComboBox;

                if (cb.SelectedItem == null)
                    return;

                TheLoai selected = cb.SelectedItem as TheLoai;
                maTL = selected.Matl;
                LoadDiaByTheLoai(maTL);

            }
*/
        }


        void LoadDiaByTheLoai(string id)
        {
            flStore.Controls.Clear();

            List<Dia> dialist = DiaDAO.Instance.GetDiaByMaTheLoai(id);

            foreach( Dia item in dialist)
            {
                Button btn = new Button() { Width = DiaDAO.DiaWidth, Height = DiaDAO.DiaHeight };
                btn.Text = item.Tendia;
                // btn.BackgroundImage = Image.FromFile(item.Anh);
                // btn.BackgroundImageLayout = ImageLayout.Stretch;
                btn.Tag = item;
                btn.Click += btn_Click;

                flStore.Controls.Add(btn);


            }
        }


        void LoadDiaByNSX(string id)
        {
            flStore.Controls.Clear();

            List<Dia> dialist = DiaDAO.Instance.GetDiaByMaNSX(id);

            foreach (Dia item in dialist)
            {
                Button btn = new Button() { Width = DiaDAO.DiaWidth, Height = DiaDAO.DiaHeight };
                btn.Text = item.Tendia;
                // btn.BackgroundImage = Image.FromFile(item.Anh);
                // btn.BackgroundImageLayout = ImageLayout.Stretch;
                btn.Tag = item;
                btn.Click += btn_Click;

                flStore.Controls.Add(btn);


            }
        }

        void LoadDiaByNSXvaMaTL(string id, string id1)
        {
            flStore.Controls.Clear();

            List<Dia> dialist = DiaDAO.Instance.GetDiaByMaNSXvaMaTL(id,id1);

            foreach (Dia item in dialist)
            {
                Button btn = new Button() { Width = DiaDAO.DiaWidth, Height = DiaDAO.DiaHeight };
                btn.Text = item.Tendia;
                // btn.BackgroundImage = Image.FromFile(item.Anh);
                // btn.BackgroundImageLayout = ImageLayout.Stretch;
                btn.Tag = item;
                btn.Click += btn_Click;

                flStore.Controls.Add(btn);


            }
        }
        private void cbTheLoai_Click(object sender, EventArgs e)
        {
            // HienTheLoaiTheoID();


        }

        private void btnTim_Click(object sender, EventArgs e)
        {

            if(cbTheLoai.SelectedIndex >-1 && cbNSX.SelectedIndex > -1)
            {
                string maNSX = "";
                string maTL = "";


                if (cbNSX.SelectedItem == null && cbTheLoai.SelectedItem==null)
                    return;

                TheLoai selected1 = cbTheLoai.SelectedItem as TheLoai;
                maTL = selected1.Matl;
                NSX selected = cbNSX.SelectedItem as NSX;
                maNSX = selected.MaNSX;
                maTL = selected1.Matl;

                LoadDiaByNSXvaMaTL(maNSX, maTL);
            }
            else if (cbTheLoai.SelectedIndex > -1)
            {
                string maTL = "";


                if (cbTheLoai.SelectedItem == null)
                    return;

                TheLoai selected = cbTheLoai.SelectedItem as TheLoai;
                maTL = selected.Matl;
                LoadDiaByTheLoai(maTL);

            }
            else if (cbNSX.SelectedIndex > -1)
            {
                string maNSX = "";


                if (cbNSX.SelectedItem == null)
                    return;

                NSX selected = cbNSX.SelectedItem as NSX;
                maNSX = selected.MaNSX;
                LoadDiaByNSX(maNSX);
            }
        }

        private void btnTim_MouseLeave(object sender, EventArgs e)
        {
 
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            HienThi();




        }
    }
}
