﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QLbandia.dtos;

namespace QLbandia.DAO
{
    internal class TheLoaiDAO
    {
        private static TheLoaiDAO instance;

        public static TheLoaiDAO Instance
        {
            get { if (instance == null) instance = new TheLoaiDAO(); return TheLoaiDAO.instance; }
            private set { TheLoaiDAO.instance = value; }
        }

        private TheLoaiDAO() { }

        public List<TheLoai> GetListCategory()
        {
            List<TheLoai> list = new List<TheLoai>();

            string query = "select * from tTheLoai";

            DataTable data = DataProvider.Instance.ExecuteQuery(query);

            foreach (DataRow item in data.Rows)
            {
                TheLoai category = new TheLoai(item);
                list.Add(category);
            }

            return list;
        }


        public TheLoai GetCategoryByID(string id)
        {
            TheLoai category = null;

            string query = "select * from tTheLoai where MaTheLoai = " + id;

            DataTable data = DataProvider.Instance.ExecuteQuery(query);

            foreach (DataRow item in data.Rows)
            {
                category = new TheLoai(item);
                return category;
            }

            return category;
        }
    }
}
