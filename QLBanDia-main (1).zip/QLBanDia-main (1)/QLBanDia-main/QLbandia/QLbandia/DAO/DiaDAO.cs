﻿
using QLbandia.dtos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLbandia.DAO
{
    public class DiaDAO
    {
        private static DiaDAO instance;

        public static DiaDAO Instance
        {
            get { if (instance == null) instance = new DiaDAO(); return DiaDAO.instance; }
            private set { DiaDAO.instance = value; }
        }

        public static int DiaWidth = 90;
        public static int DiaHeight = 90;

        private DiaDAO() { }

        public List<Dia> LoadDiaList()
        {
            List<Dia> dialist = new List<Dia>();

            DataTable data = DataProvider.Instance.ExecuteQuery("USP_GetAlbumList");

            foreach (DataRow item in data.Rows)
            {
                Dia dia = new Dia(item);
                dialist.Add(dia);
            }

            return dialist;
        }

        public Dia GetDiaByMaDia(string madia)
        {
            
            string query = $"select * from tKhoDia where MaDia = N'{madia}'";
            DataTable data = DataProvider.Instance.ExecuteQuery(query);
            Dia dia = new Dia(data.Rows[0]);
            return dia;
        }
        public List<Dia> GetDiaByMaTheLoai(string madia)
        {
            List<Dia> list = new List<Dia>();

            string query = $"select * from tKhoDia where MaTL = N'{madia}'";
            DataTable data = DataProvider.Instance.ExecuteQuery(query);
            foreach (DataRow item in data.Rows)
            {
                Dia dia = new Dia(item);
                list.Add(dia);
            }

            return list;
        }

        public List<Dia> GetDiaByMaNSX(string madia)
        {
            List<Dia> list = new List<Dia>();

            string query = $"select * from tKhoDia where MaNSX = N'{madia}'";
            DataTable data = DataProvider.Instance.ExecuteQuery(query);
            foreach (DataRow item in data.Rows)
            {
                Dia dia = new Dia(item);
                list.Add(dia);
            }

            return list;
        }

        public List<Dia> GetDiaByMaNSXvaMaTL(string madia,string madia1)
        {
            List<Dia> list = new List<Dia>();

            string query = $"select * from tKhoDia where MaNSX = N'{madia}' and MaTL = N'{madia1}'";
            DataTable data = DataProvider.Instance.ExecuteQuery(query);
            foreach (DataRow item in data.Rows)
            {
                Dia dia = new Dia(item);
                list.Add(dia);
            }

            return list;
        }
    }


}
